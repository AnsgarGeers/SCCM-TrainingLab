$logpath = "$($env:windir)\temp\DownloadSoftware.ps1.log"
$rootFolder = "C:\TrainingFiles"

##Functions
Function Write-Log
{
	PARAM (
		[String]$Message,
		[int]$severity = 1
	)
	$TimeZoneBias = Get-WmiObject -Query "Select Bias from Win32_TimeZone"
	$Date = Get-Date -Format "HH:mm:ss.fff"
	$Date2 = Get-Date -Format "MM-dd-yyyy"
	$type = 1
	
	if (($logpath -ne $null) -and ($logpath -ne ''))
	{
		"<![LOG[$Message]LOG]!><time=`"$date+$($TimeZoneBias.bias)`" date=`"$date2`" component=`"$component`" context=`"`" type=`"$severity`" thread=`"`" file=`"`">" | Out-File -FilePath $logpath -Append -NoClobber -Encoding default
	}
	
	switch ($severity)
	{
		3 { Write-Host $Message -ForegroundColor Red }
		2 { Write-Host $Message -ForegroundColor Yellow }
		1 { Write-Host $Message }
	}
}

function Get-File
{
	param (
		[string]$URL,
		[string]$Path,
		[string]$FileName
	)
	$FilePath = "$Path\$FileName"
	
	if (Test-Path $filePath)
	{
		Write-log -message "file $FilePath already exist, ignoring it" -severity 2
		return
	}
	
	try
	{
		Write-log -message "Downloading $URL to $FilePath" -severity 1
		$WebClient = New-Object System.Net.WebClient
		$WebClient.DownloadFile($URL, $FilePath)
	}
	catch
	{
		Write-log -message "Failed to download from [$URL]" -severity 3
		Write-log -message "Error: $_" -severity 3
	}
}

function New-Folder
{
	param (
		[string]$FolderPath
	)
	if (!(Test-Path $FolderPath))
	{
		Write-log -message "Creating folder $FolderPath" -severity 1
		New-Item ($FolderPath) -type directory -force | out-null
	}
	else
	{
		Write-log -message "folder $FolderPath already exist, ignoring it" -severity 2
	}
	
}

Function Test-RFLPath
{

}

##Variables
$Folders1stLevel = "GPO;Isos;OSCaptured;Scripts;Source;vhdx;AnswerFiles"
$eicarString1 = 'X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR'
$eicarString2 = '-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*'

$downloadFiles = @(
"7-zip;http://7-zip.org/a/7z1514-x64.exe;7z1514-x64.exe",
"AdobeXI;ftp://ftp.adobe.com/pub/adobe/reader/win/11.x/11.0.10/en_US/AdbeRdr11010_en_US.exe;AdbeRdr11010_en_US.exe",
"AdobeXI;ftp://ftp.adobe.com/pub/adobe/reader/win/11.x/11.0.13/misc/AdbeRdrUpd11013.msp;AdbeRdrUpd11013.msp",
"Chrome for Windows;https://dl.google.com/tag/s/appguid%3D%7B8A69D345-D564-463C-AFF1-A69D9E530F96%7D%26iid%3D%7B192FC5FF-D47F-3F0A-0CC2-98B4D8DAF3AE%7D%26lang%3Den%26browser%3D4%26usagestats%3D0%26appname%3DGoogle%2520Chrome%26needsadmin%3Dprefers/edgedl/chrome/install/GoogleChromeStandaloneEnterprise.msi;GoogleChromeStandaloneEnterprise.msi",
"Chrome for Linux;https://dl.google.com/linux/direct/google-chrome-stable_current_x86_64.rpm;google-chrome-stable_current_x86_64.rpm",
"Firefox 42;https://ftp.mozilla.org/pub/firefox/releases/42.0/win32/en-US/Firefox%20Setup%2042.0.exe;Firefox Setup 42.0.exe ",
"Firefox 40;https://ftp.mozilla.org/pub/firefox/releases/40.0/win32/en-US/Firefox%20Setup%2040.0.exe;Firefox Setup 40.0.exe",
"Java8;http://javadl.sun.com/webapps/download/AutoDL?BundleId=101408;Java8.exe",
"Robocopy App-V5 Download;http://bit.ly/17h1rjP;Robocopy App-V5.zip",
"AdkW10Download;http://download.microsoft.com/download/8/1/9/8197FEB9-FABE-48FD-A537-7D8709586715/adk/adksetup.exe;adksetup.exe",
"WSUSKB3095113;http://hotfixv4.microsoft.com/Windows 8.1/Windows Server 2012 R2/sp1/Fix4511610/9600/free/487296_intl_x64_zip.exe;487296_intl_x64_zip.exe",
"SCCMCB;http://care.dlservice.microsoft.com/dl/download/E/F/3/EF388C92-F307-42B7-989F-FF4DA328B328/SC_Configmgr_1511.exe;SC_Configmgr_CB.exe",
"SCCMCB-LinuxClient;https://download.microsoft.com/download/B/8/5/B855F253-8EB6-4E4B-A6D8-E32A23D5EB8B/Config%20Mgr%20Clients%20for%20Linux.EXE;Config Mgr Clients for Linux.EXE",
"SCCMCB-Toolkit;https://download.microsoft.com/download/5/0/8/508918E1-3627-4383-B7D8-AA07B3490D21/ConfigMgrTools.msi;ConfigMgrTools.msi",
"SCCMCB-PoshCmdlet;https://download.microsoft.com/download/8/4/3/843CDC53-B4B1-4E38-98D7-3CED81FC04F6/ConfigMgr2012PowerShellCmdlets.msi;ConfigMgr2012PowerShellCmdlets.msi",
"SCUP2011;https://download.microsoft.com/download/4/4/2/442F4D26-8331-4386-98F4-C17A3A89F46C/SystemCenterUpdatesPublisher.msi;SystemCenterUpdatesPublisher.msi"
)

$downloadIsos = @(
"http://buildlogs.centos.org/rolling/7/isos/x86_64/CentOS-7-x86_64-Everything.iso;CentOS-7-x86_64-Everything.iso",
"http://mirror.vyos.net/iso/release/1.1.3/vyos-1.1.3-amd64.iso;vyos-1.1.3-amd64.iso",
"http://downloads.sourceforge.net/project/android-x86/Release%204.4/android-x86-4.4-r2.iso?r=http%3A%2F%2Fsourceforge.net%2Fprojects%2Fandroid-x86%2Ffiles%2FRelease%25204.4%2F&ts=1423649395&use_mirror=softlayer-ams;android-x86-4.4-r2.iso",
"http://care.dlservice.microsoft.com/dl/download/B/9/9/B999286E-0A47-406D-8B3D-5B5AD7373A4A/9600.17050.WINBLUE_REFRESH.140317-1640_X64FRE_ENTERPRISE_EVAL_EN-US-IR3_CENA_X64FREE_EN-US_DV9.ISO;W81EE.ISO",
"http://care.dlservice.microsoft.com/dl/download/C/3/9/C399EEA8-135D-4207-92C9-6AAB3259F6EF/10240.16384.150709-1700.TH1_CLIENTENTERPRISEEVAL_OEMRET_X64FRE_EN-US.ISO;W10EETH1.iso",
"http://care.dlservice.microsoft.com/dl/download/B/B/3/BB3611B6-9781-437F-A293-AB43B85C2190/10586.0.151029-1700.TH2_RELEASE_CLIENTENTERPRISEEVAL_OEMRET_X64FRE_EN-US.ISO;W10EETH2.iso",
"http://care.dlservice.microsoft.com/dl/download/6/2/A/62A76ABB-9990-4EFC-A4FE-C7D698DAEB96/9600.17050.WINBLUE_REFRESH.140317-1640_X64FRE_SERVER_EVAL_EN-US-IR3_SSS_X64FREE_EN-US_DV9.ISO;WS2012R2.ISO",
"http://care.dlservice.microsoft.com/dl/download/2/F/8/2F8F7165-BB21-4D1E-B5D8-3BD3CE73C77D/SQLServer2014SP1-FullSlipstream-x64-ENU.iso;SQLServer2014SP1-FullSlipstream-x64-ENU.iso",
"http://download.microsoft.com/download/F/1/0/F10113F5-B750-4969-A255-274341AC6BCE/GRMSDK_EN_DVD.iso;GRMSDK_EN_DVD.iso"
)

##Main Script
Write-log -message "Starting Script" -severity 1
Write-log -message "Root Folder is $rootFolder " -severity 1

New-Folder -FolderPath ("$rootFolder")

foreach ($folder in $Folders1stLevel.Split(";"))
{
	New-Folder -FolderPath ("$($rootFolder)\$($folder)")
}

foreach ($download in $downloadFiles)
{
	$downinfo = $download.split(";")
    New-Folder -FolderPath ("$($rootFolder)\source\$($downinfo[0])")
	Get-File -URL $downinfo[1] -Path ("$($rootFolder)\source\$($downinfo[0])") -FileName ($downinfo[2])
}

foreach ($download in $downloadIsos)
{
	$downinfo = $download.split(";")
	Get-File -URL $downinfo[0] -Path ("$($rootFolder)\isos") -FileName ($downinfo[1])
}

##Create EICAR AV Test File
try
{
	if (Test-Path "$($rootFolder)\source\Eicar\eicar test file.txt")
	{
		Write-log -message "file $($rootFolder)\source\Eicar\eicar test file.txt already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Creating EICAR AV TEST File" -severity 1
		New-Folder -FolderPath ("$($rootFolder)\source\Eicar")
		"$($eicarString1)$($eicarString2)" | Out-File -FilePath "$($rootFolder)\source\Eicar\eicar test file.txt" -Encoding default
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}

##Extract robocopy
try
{
	if (Test-Path "$($rootFolder)\source\Robocopy App-v5")
	{
		Write-log -message "Folder $($rootFolder)\source\Robocopy App-v5 already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Extract robocopy" -severity 1
		[System.Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')
		[System.IO.Compression.ZipFile]::ExtractToDirectory("$($rootFolder)\source\Robocopy App-V5 Download\Robocopy App-v5.zip", "$($rootFolder)\source")
		start-sleep 5
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}

##Makecert
try
{
	if (Test-Path "$($rootFolder)\Source\makecert\makecert.exe")
	{
		Write-log -message "file $($rootFolder)\Source\makecert\makecert.exe already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Creating makecert file" -severity 1
		New-Folder -FolderPath ("$($rootFolder)\source\makecert")
		Mount-DiskImage -ImagePath ("$($rootFolder)\Isos\GRMSDK_EN_DVD.iso")
		start-sleep 5
		$DriveLetter = (Get-Volume | Where-Object { $_.DriveType -eq "CD-ROM" }).DriveLetter
		expand "$($DriveLetter):\Setup\WinSDKTools\cab1.cab" /f:WinSDK_makecert_exe_24DFD147_3F96_47FC_B09E_5FCACE50CD4C_x86 "$($rootFolder)\Source\makecert"
		start-sleep 5
		Move-Item -Path "$($rootFolder)\Source\makecert\WinSDK_makecert_exe_24DFD147_3F96_47FC_B09E_5FCACE50CD4C_x86" -Destination "$($rootFolder)\Source\makecert\makecert.exe"
		Dismount-DiskImage -ImagePath ("$($rootFolder)\Isos\GRMSDK_EN_DVD.iso")
		start-sleep 5
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}

##adkW10 download files
try
{
	if (Test-Path "$($rootFolder)\source\AdkW10Download")
	{
		Write-log -message "Folder $($rootFolder)\source\AdkW10Download already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Executing adksetup" -severity 1
	}
} 
catch
{
	Write-log -message "Error: $_" -severity 3
}

##adkW10 extract files
try
{
	if (Test-Path "$($rootFolder)\source\AdkW10")
	{
		Write-log -message "Folder $($rootFolder)\source\AdkW10 already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Executing adksetup" -severity 1
		New-Folder -FolderPath ("$($rootFolder)\source\adkW10")
		Start-Process -Filepath ("$($rootFolder)\source\AdkW10Download\adksetup.exe") -ArgumentList ("/layout $($rootFolder)\source\AdkW10 /quiet") -Wait
	}
} 
catch
{
	Write-log -message "Error: $_" -severity 3
}

##Extract SCCM CB Files
try
{
	if (Test-Path "$($rootFolder)\source\SCCMCB\Extract")
	{
		Write-log -message "Folder $($rootFolder)\source\SCCMCB\Extract already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Extract SCCM CB Files" -severity 1
		Start-Process -Filepath ("$($rootFolder)\source\SCCMCB\SC_Configmgr_CB.exe") -ArgumentList ("/auto") -wait
		start-sleep 5
		Start-Process -FilePath ("c:\windows\system32\robocopy.exe") -ArgumentList ("C:\SC_Configmgr_1511 $($rootFolder)\source\SCCMCB\Extract /s /e /copy:DAT /r:1 /w:1 /xj /xjd /xjf") -wait
		Remove-Item "C:\SC_Configmgr_1511" -force -recurse
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}

##SCCM Redist Files
try
{
	if (Test-Path "$($rootFolder)\source\SCCMCB\Redist")
	{
		Write-log -message "Folder $($rootFolder)\source\SCCMCB\Redist already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "SCCM Redist Files" -severity 1
		Start-Process -Filepath ("$($rootFolder)\source\SCCMCB\Extract\SMSSETUP\BIN\X64\setupdl.exe") -ArgumentList ("$($rootFolder)\source\SCCMCB\Redist") -wait
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}

##Extract SCCM Linux Files
try
{
	if (Test-Path "$($rootFolder)\source\SCCMCB-LinuxClient\Extract")
	{
		Write-log -message "Folder $($rootFolder)\source\SCCMCB-LinuxClient\Extract already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Extract SCCM Linux Files" -severity 1
		Start-Process -Filepath ("$($rootFolder)\source\SCCMCB-LinuxClient\Config Mgr Clients for Linux.EXE") -ArgumentList ("/q /C /T:$($rootFolder)\source\SCCMCB-LinuxClient\Extract") -wait
		start-sleep 5
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}

##Extract WSUS KB3095113
try
{
	if (Test-Path "$($rootFolder)\source\WSUSKB3095113\Extract")
	{
		Write-log -message "Folder $($rootFolder)\source\WSUSKB3095113\Extract already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Extract WSUS KB3095113" -severity 1
		[System.Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')
		[System.IO.Compression.ZipFile]::ExtractToDirectory("$($rootFolder)\source\WSUSKB3095113\487296_intl_x64_zip.exe", "$($rootFolder)\source\WSUSKB3095113\Extract")
		start-sleep 5
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}

##Extract W10 EE TH1
try
{
	if (Test-Path "$($rootFolder)\source\W10EETH1")
	{
		Write-log -message "Folder $($rootFolder)\source\W10EETH1 already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Extract W10 EE TH1" -severity 1
		Mount-DiskImage -ImagePath ("$($rootFolder)\isos\W10EETH1.iso")
		start-sleep 5
		$DriveLetter = (Get-Volume | Where-Object { $_.DriveType -eq "CD-ROM" }).DriveLetter
		Start-Process -FilePath ("c:\windows\system32\robocopy.exe") -ArgumentList ("$($DriveLetter):\ $($rootFolder)\source\W10EETH1 /s /e /copy:DAT /r:1 /w:1 /xj /xjd /xjf") -wait
		Dismount-DiskImage -ImagePath ("$($rootFolder)\isos\W10EETH1.iso")
		start-sleep 5
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}

##Extract W10 EE TH2
try
{
	if (Test-Path "$($rootFolder)\source\W10EETH2")
	{
		Write-log -message "Folder $($rootFolder)\source\W10EETH2 already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Extract W10 EE TH2" -severity 1
		Mount-DiskImage -ImagePath ("$($rootFolder)\isos\W10EETH2.iso")
		start-sleep 5
		$DriveLetter = (Get-Volume | Where-Object { $_.DriveType -eq "CD-ROM" }).DriveLetter
		Start-Process -FilePath ("c:\windows\system32\robocopy.exe") -ArgumentList ("$($DriveLetter):\ $($rootFolder)\source\W10EETH2 /s /e /copy:DAT /r:1 /w:1 /xj /xjd /xjf") -wait
		Dismount-DiskImage -ImagePath ("$($rootFolder)\isos\W10EETH2.iso")
		start-sleep 5
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}

##Extract W8.1 EE
try
{
	if (Test-Path "$($rootFolder)\source\W81EE")
	{
		Write-log -message "Folder $($rootFolder)\source\W81EE already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Extract W8.1 EE" -severity 1
		Mount-DiskImage -ImagePath ("$($rootFolder)\isos\W81EE.ISO")
		start-sleep 5
		$DriveLetter = (Get-Volume | Where-Object { $_.DriveType -eq "CD-ROM" }).DriveLetter
		Start-Process -FilePath ("c:\windows\system32\robocopy.exe") -ArgumentList ("$($DriveLetter):\ $($rootFolder)\source\W81EE /s /e /copy:DAT /r:1 /w:1 /xj /xjd /xjf") -wait
		Dismount-DiskImage -ImagePath ("$($rootFolder)\isos\W81EE.ISO")
		start-sleep 5
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}

##Extract WS2012R2
try
{
	if (Test-Path "$($rootFolder)\source\WS2012R2")
	{
		Write-log -message "Folder $($rootFolder)\source\WS2012R2 already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Extract WS2012R2" -severity 1
		Mount-DiskImage -ImagePath ("$($rootFolder)\isos\WS2012R2.ISO")
		start-sleep 5
		$DriveLetter = (Get-Volume | Where-Object { $_.DriveType -eq "CD-ROM" }).DriveLetter
		Start-Process -FilePath ("c:\windows\system32\robocopy.exe") -ArgumentList ("$($DriveLetter):\ $($rootFolder)\source\WS2012R2 /s /e /copy:DAT /r:1 /w:1 /xj /xjd /xjf") -wait
		Dismount-DiskImage -ImagePath ("$($rootFolder)\isos\WS2012R2.ISO")
		start-sleep 5
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}

##Extract SQL2014SP1
try
{
	if (Test-Path "$($rootFolder)\source\SQL2014SP1")
	{
		Write-log -message "Folder $($rootFolder)\source\SQL2014SP1 already exist, ignoring it" -severity 2
	}
	else
	{
		Write-log -message "Extract SQL2014SP1" -severity 1
		Mount-DiskImage -ImagePath ("$($rootFolder)\isos\SQLServer2014SP1-FullSlipstream-x64-ENU.iso")
		start-sleep 5
		$DriveLetter = (Get-Volume | Where-Object { $_.DriveType -eq "CD-ROM" }).DriveLetter
		Start-Process -FilePath ("c:\windows\system32\robocopy.exe") -ArgumentList ("$($DriveLetter):\ $($rootFolder)\source\SQL2014SP1 /s /e /copy:DAT /r:1 /w:1 /xj /xjd /xjf") -wait
		start-sleep 5
	}
}
catch
{
	Write-log -message "Error: $_" -severity 3
}